Aviator Predictor Pro — Android Starter Project

हे APK नाही; Android Studio मध्ये उघडून build करायचा source project आहे.

काय आहे:
- मराठी Dashboard
- हाताने Multiplier नोंदवणे
- 1.5x आणि 2x किंवा अधिक यांची मोजणी
- Android overlay permission मागणारी Floating Window सेवा

मर्यादा:
- IPLWIN/SPRIBE मधून Live निकाल आपोआप वाचत नाही.
- पुढचा Crash Point predict किंवा hack करत नाही.
- Overlay मध्ये सध्या demo मजकूर आहे; पुढील आवृत्तीत dashboard शी live जोडणी करावी लागेल.

Build:
1. Android Studio मध्ये हा folder उघडा.
2. Gradle sync पूर्ण होऊ द्या.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. फोनवर install केल्यानंतर Floating Window साठी 'Display over other apps' परवानगी द्या.

टीप: targetSdk 28 हा overlay prototype सोपा ठेवण्यासाठी आहे. सार्वजनिक वितरणापूर्वी target SDK, privacy आणि Play policy requirements अपडेट करणे आवश्यक आहे.
