package com.example.aviatorpredictorpro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val rounds = mutableListOf<Double>()
    private lateinit var stats: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Aviator Predictor Pro"
            textSize = 25f
        })
        layout.addView(TextView(this).apply {
            text = "मराठी • IPLWIN / SPRIBE Aviator इतिहास विश्लेषण"
            textSize = 16f
        })
        input = EditText(this).apply {
            hint = "आलेला Multiplier लिहा (उदा. 1.75)"
            inputType = 8194
        }
        layout.addView(input)
        val add = Button(this).apply {
            text = "राऊंड नोंदवा"
            setOnClickListener {
                val value = input.text.toString().trim().replace("x", "").toDoubleOrNull()
                if (value == null || value < 1.0) {
                    Toast.makeText(this@MainActivity, "कृपया योग्य Multiplier लिहा.", Toast.LENGTH_SHORT).show()
                } else {
                    rounds.add(0, value)
                    if (rounds.size > 100) rounds.removeAt(rounds.lastIndex)
                    input.text.clear()
                    refresh()
                    OverlayService.update(this@MainActivity, rounds)
                }
            }
        }
        layout.addView(add)
        stats = TextView(this).apply { textSize = 17f; setPadding(0, 20, 0, 20) }
        layout.addView(stats)
        val overlay = Button(this).apply {
            text = "Floating Window सुरू करा"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    OverlayService.update(this@MainActivity, rounds)
                }
            }
        }
        layout.addView(overlay)
        layout.addView(Button(this).apply {
            text = "Floating Window बंद करा"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        layout.addView(TextView(this).apply {
            text = "\nसूचना: हा अॅप फक्त तुम्ही नोंदवलेल्या राऊंडचे आकडे मोजतो. पुढचा निकाल सांगत नाही. IPLWIN मधून स्वयंचलित डेटा मिळवणे यात समाविष्ट नाही."
            textSize = 14f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
        refresh()
    }

    private fun refresh() {
        val oneFive = rounds.count { it >= 1.5 }
        val two = rounds.count { it >= 2.0 }
        val total = rounds.size
        stats.text = "नोंदवलेले राऊंड: $total\n1.5x किंवा अधिक: $oneFive (${pct(oneFive,total)})\n2x किंवा अधिक: $two (${pct(two,total)})\n\nअलीकडील राऊंड: " +
            rounds.take(12).joinToString(" • ") { "%.2fx".format(it) }
    }
    private fun pct(n: Int, d: Int) = if (d == 0) "—" else "%.1f%%".format(n * 100.0 / d)
}
