package com.example.aviatorpredictorpro

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
    private var window: WindowManager? = null
    private var panel: TextView? = null

    override fun onCreate() {
        super.onCreate()
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        panel = TextView(this).apply {
            text = "Aviator Analysis\nराऊंड नोंदवा"
            textSize = 15f
            setPadding(22, 18, 22, 18)
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD202020.toInt())
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 180 }
        panel?.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var wx = 0; var wy = 0
            override fun onTouch(v: View, e: android.view.MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx=e.rawX; sy=e.rawY
                        wx=(v.layoutParams as WindowManager.LayoutParams).x
                        wy=(v.layoutParams as WindowManager.LayoutParams).y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val p=v.layoutParams as WindowManager.LayoutParams
                        p.x=wx+(e.rawX-sx).toInt(); p.y=wy+(e.rawY-sy).toInt()
                        window?.updateViewLayout(v,p); return true
                    }
                }
                return false
            }
        })
        window?.addView(panel, params)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        panel?.let { window?.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun update(context: Context, rounds: List<Double>) {
            val total=rounds.size
            val a=rounds.count { it>=1.5 }
            val b=rounds.count { it>=2.0 }
            val msg="Aviator Analysis\nनोंद: $total राऊंड\n≥1.5x: $a (${percent(a,total)})\n≥2x: $b (${percent(b,total)})\nहा इतिहास आहे; पुढचा निकाल नाही."
            // Service instance is intentionally not accessed statically; dashboard remains the source of truth.
            context.getSharedPreferences("stats", Context.MODE_PRIVATE).edit().putString("overlay_text",msg).apply()
        }
        private fun percent(n:Int,d:Int)=if(d==0) "—" else "%.0f%%".format(n*100.0/d)
    }
}
